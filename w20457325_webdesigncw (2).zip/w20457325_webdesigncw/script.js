document.addEventListener("DOMContentLoaded", function() {
    var currentLocation = window.location.href;  // Get the current URL of the page
    var navLinks = document.querySelectorAll(".navbar a"); // Select all navigation links in the navbar
 // Loop through each navigation link checking if it matches with the current url to display a hover over the current one
    navLinks.forEach(function(navLink) {
        if (navLink.href === currentLocation) {
            navLink.classList.add("active");
        }
    });
});
// scroll.js

// Function to scroll back to the top of the page
function scrollToTop() {
    window.scrollTo({top: 0, behavior: 'smooth'});
  }
  
  // Show or hide the scroll button based on scroll position
  window.onscroll = function() {scrollFunction()};
  function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      document.getElementById("scrollBtn").style.display = "block";
  // If scroll position is greater than 20px from top, display the scroll button

    } else {
      document.getElementById("scrollBtn").style.display = "none";
    }
  // Else hide the scroll button
  }
  